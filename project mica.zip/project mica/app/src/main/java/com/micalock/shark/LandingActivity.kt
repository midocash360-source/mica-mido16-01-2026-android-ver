package com.micalock.shark

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

class LandingActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var indicatorContainer: android.widget.LinearLayout
    private val slides = listOf(
        IntroSlide("SHARK_ENGINE", "MICALOCK COMMAND CENTER", "Identity Verified and encrypted. System standby active.", android.R.drawable.ic_lock_idle_lock),
        IntroSlide("SENSORY BRAIN", "AI HEURISTICS ACTIVE", "Monitoring G-Force, RSSI Decay, and hardware tampering in real-time.", android.R.drawable.ic_menu_view),
        IntroSlide("DECEPTION BLUFF", "POWER HIJACK PROTOCOL", "3.5s Fake Shutdown Enabled. Capturing hardware evidence on intrusion.", android.R.drawable.ic_lock_power_off),
        IntroSlide("TRIBE MESH", "P2P GUARDIAN NETWORK", "Connecting to encrypted nodes. Deploying Shark Sentinel...", android.R.drawable.ic_dialog_map)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landing)

        viewPager = findViewById(R.id.introPager)
        indicatorContainer = findViewById(R.id.indicatorContainer)
        viewPager.adapter = IntroAdapter(slides)

        val btnNext = findViewById<Button>(R.id.btnNext)
        val btnPrevious = findViewById<Button>(R.id.btnPrevious)

        setupIndicators()
        updateIndicators(0)

        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicators(position)
                
                // Show/Hide Previous Button
                btnPrevious.visibility = if (position == 0) View.GONE else View.VISIBLE
                
                if (position == slides.size - 1) {
                    btnNext.text = "ENTER  >"
                    btnNext.setTextColor(androidx.core.content.ContextCompat.getColor(this@LandingActivity, R.color.tactical_black))
                    btnNext.setBackgroundResource(R.drawable.btn_tactical_solid)
                } else {
                    btnNext.text = "NEXT  >"
                    btnNext.setTextColor(androidx.core.content.ContextCompat.getColor(this@LandingActivity, R.color.tactical_cyan))
                    btnNext.setBackgroundResource(R.drawable.btn_tactical_outline)
                }
            }
        })

        btnNext.setOnClickListener {
            val current = viewPager.currentItem
            if (current < slides.size - 1) {
                 viewPager.currentItem = current + 1
            } else {
                requestPermissionsAndStart()
            }
        }

        btnPrevious.setOnClickListener {
            val current = viewPager.currentItem
            if (current > 0) {
                viewPager.currentItem = current - 1
            }
        }
    }

    private fun setupIndicators() {
        val indicators = arrayOfNulls<android.widget.ImageView>(slides.size)
        val layoutParams = android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(8, 0, 8, 0)
        for (i in indicators.indices) {
            indicators[i] = android.widget.ImageView(applicationContext)
            indicators[i]?.setImageDrawable(androidx.core.content.ContextCompat.getDrawable(
                applicationContext, android.R.drawable.presence_invisible
            ))
            indicatorContainer.addView(indicators[i], layoutParams)
        }
    }

    private fun updateIndicators(position: Int) {
        val childCount = indicatorContainer.childCount
        for (i in 0 until childCount) {
            val imageView = indicatorContainer.getChildAt(i) as android.widget.ImageView
            if (i == position) {
                imageView.alpha = 1.0f
                imageView.scaleX = 1.5f
                imageView.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.tactical_cyan))
                // Make it a dash
                val lp = imageView.layoutParams
                lp.width = 40
                lp.height = 8
                imageView.layoutParams = lp
            } else {
                imageView.alpha = 0.3f
                imageView.scaleX = 1.0f
                imageView.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.tactical_cyan))
                // Make it a dot
                val lp = imageView.layoutParams
                lp.width = 8
                lp.height = 8
                imageView.layoutParams = lp
            }
        }
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.VIBRATE
        )
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        
        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 101)
        } else {
            completeIntro()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Ensure we proceed to complete intro regardless of permission choice
        completeIntro()
    }

    private fun completeIntro() {
        // Robust transition to MainActivity
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(mainIntent)
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    data class IntroSlide(val title: String, val subTitle: String, val desc: String, val iconRes: Int)

    inner class IntroAdapter(private val items: List<IntroSlide>) : RecyclerView.Adapter<IntroAdapter.SlideViewHolder>() {
        inner class SlideViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val titleText: TextView = view.findViewById(R.id.slideTitle)
            val subTitleText: TextView = view.findViewById(R.id.slideSubTitle)
            val descText: TextView = view.findViewById(R.id.slideDesc)
            val iconView: android.widget.ImageView = view.findViewById(R.id.slideIcon)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SlideViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_intro_slide, parent, false)
            return SlideViewHolder(view)
        }
        override fun onBindViewHolder(holder: SlideViewHolder, position: Int) {
            holder.titleText.text = items[position].title
            holder.subTitleText.text = items[position].subTitle
            holder.descText.text = items[position].desc
            holder.iconView.setImageResource(items[position].iconRes)
        }
        override fun getItemCount() = items.size
    }
}
