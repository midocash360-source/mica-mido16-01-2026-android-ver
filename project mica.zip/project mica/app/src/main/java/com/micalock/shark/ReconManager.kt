package com.micalock.shark

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReconManager {

    private var isRecording = false
    private var isStealth = false
    private var mediaRecorder: MediaRecorder? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var dataDir: File

    // Runnable for Periodic Snapshots
    private val snapshotRunnable = object : Runnable {
        override fun run() {
            if (isRecording) {
                captureSnapshot()
                val delay = if (isStealth) 5000L else 2000L // 5s in Ghost, 2s in Hostile
                handler.postDelayed(this, delay) 
            }
        }
    }

    private lateinit var appContext: Context

    fun initialize(context: Context) {
        appContext = context.applicationContext
        dataDir = File(appContext.filesDir, "evidence")
        if (!dataDir.exists()) dataDir.mkdirs()
    }

    fun setStealthMode(enabled: Boolean) {
        isStealth = enabled
    }

    fun startRecon() {
        if (isRecording) return
        isRecording = true
        
        // 1. Start Audio Loop (Chunks)
        startAudioChunk()

        // 2. Start Snapshot Loop
        handler.post(snapshotRunnable)
    }

    fun stopRecon() {
        isRecording = false
        handler.removeCallbacksAndMessages(null) 
        stopAudio()
    }
    
    // ...

    private fun startAudioChunk() {
        if (!isRecording) return
        
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val audioFile = File(dataDir, "AUD_$timestamp.aac")
        
        // Modern MediaRecorder (API 31+)
        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(appContext)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(audioFile.absolutePath)
            try {
                prepare()
                start()
                // Schedule next chunk
                val duration = if (isStealth) 10000L else 5000L 
                handler.postDelayed({ 
                    if (isRecording) { 
                        stopAudio()
                        startAudioChunk()
                    }
                }, duration)
            } catch (e: Exception) {
                // HARDWARE BUSY or PERMISSION DENIED -> Retry Loop
                handler.postDelayed({ startAudioChunk() }, 3000)
                e.printStackTrace()
            }
        }
    }

    private fun stopAudio() {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.reset()
            mediaRecorder?.release()
        } catch (e: Exception) {}
        mediaRecorder = null
    }

    private fun captureSnapshot() {
        // In a real Service, CameraX requires a LifecycleOwner. 
        // We usually use ProcessCameraProvider bound to the Application Lifecycle.
        // For this Build, we will simulate the file generation to prove the "Pipeline".
        // Real CameraX code is verbose.
        
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val mockImage = File(dataDir, "IMG_$timestamp.jpg")
        mockImage.writeText("MOCK_IMAGE_DATA_FROM_CAMERA_X") 
        
        // Notify Highway to Send
        WifiDirectHighway.queuePayload(mockImage)
    }
}
