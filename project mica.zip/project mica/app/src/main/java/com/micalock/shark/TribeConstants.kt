package com.micalock.shark

object TribeConstants {
    // RSSI ZONES (dBm)
    const val RSSI_SAFE_ZONE = -65  // > -65 is Safe (Close)
    const val RSSI_DRIFT_START = -70 // -70 to -85 is Drift
    const val RSSI_HOSTILE_ZONE = -90 // < -90 is Hostile (Far)

    // VELOCITY THRESHOLDS (m/s^2)
    const val SNATCH_VELOCITY_THRESHOLD = 25.0f
    
    // TIMERS (ms)
    const val DRIFT_LATENCY_MS = 7000L
    const val BIOMETRIC_GRACE_MS = 8000L 
}
