package com.micalock.shark

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor

class FakeShutdownActivity : AppCompatActivity() {

    private var tapCount = 0
    private var lastTapTime = 0L
    private val TAP_RESET_MS = 2000L
    private var keyholeSizePx = 0 
    
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 1. Modern Fullscreen (Android 11+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
        
        // 2. Dim Screen (Dead Battery Look)
        val layoutParams = window.attributes
        layoutParams.screenBrightness = 0.01f
        window.attributes = layoutParams
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        
        setContentView(R.layout.activity_fake_shutdown)
        
        // 3. Hardware Haptic "Click" (Power Off simulation)
        triggerHapticClick()
        
        // 4. Fade UI after 1.5s
        Handler(Looper.getMainLooper()).postDelayed({
            findViewById<View>(R.id.shutdownSpinner).visibility = View.GONE
            findViewById<View>(R.id.textShutdown).visibility = View.GONE
        }, 1500)
        
        setupBiometrics()
        
        // Initialize Keyhole (80dp)
        keyholeSizePx = (80 * resources.displayMetrics.density).toInt()
    }

    private fun triggerHapticClick() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(75, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(75)
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_DOWN) {
            val x = event.x
            val y = event.y
            val width = resources.displayMetrics.widthPixels
            
            // Spatial Logic: Top Right
            if (x > (width - keyholeSizePx) && y < keyholeSizePx) {
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastTapTime > TAP_RESET_MS) {
                    tapCount = 0 // Reset if too slow
                }
                
                tapCount++
                lastTapTime = currentTime
                
                if (tapCount >= 5) {
                    tapCount = 0
                    launchAuthority()
                }
            } else {
                tapCount = 0 // Missed the keyhole
            }
        }
        return super.onTouchEvent(event)
    }

    private fun setupBiometrics() {
        executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                     super.onAuthenticationSucceeded(result)
                     // SUCCESS: DISARM
                     val intent = android.content.Intent(this@FakeShutdownActivity, TribeService::class.java)
                     intent.action = "ACTION_SYSTEM_DISARM" 
                     startService(intent)
                     
                     // Restore Brightness (Optional, OS usually handles it on finish)
                     val lp = window.attributes
                     lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                     window.attributes = lp
                     
                     finish()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    // Fail -> Stay in Dark
                }
            })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MICALOCK AUTHORITY")
            .setSubtitle("Authenticate to Reboot System")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
    }

    private fun launchAuthority() {
        // Reset Brightness briefly so user can see Auth? 
        // User didn't specify, but BiometricPrompt usually draws over.
        // If screen is 0.01 brightness, they might not see the prompt well.
        // Let's bump brightness for auth.
        val lp = window.attributes
        lp.screenBrightness = 0.5f
        window.attributes = lp
        
        biometricPrompt.authenticate(promptInfo)
        
        // If cancelled, should we dim again? (Logic for error/cancel would need to handle that)
    }
    
    // Prevent Back Button
    override fun onBackPressed() {
        // Do nothing. No escape.
        // super.onBackPressed()
    }
}
