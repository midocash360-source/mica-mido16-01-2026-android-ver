package com.micalock.shark

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor

class DisarmActivity : AppCompatActivity() {

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Window Flags for Lock Screen Overlay
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            (getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager)
                .requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        
        setContentView(R.layout.activity_disarm)

        setupBiometrics()
        startCountdown()

        findViewById<Button>(R.id.btnAuthNow).setOnClickListener {
             biometricPrompt.authenticate(promptInfo)
        }
    }

    private fun setupBiometrics() {
        executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // If error is permanent (Lockout), trigger Hostile immediately
                    if (errorCode == BiometricPrompt.ERROR_LOCKOUT || errorCode == BiometricPrompt.ERROR_LOCKOUT_PERMANENT) {
                        triggerHostile()
                    }
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onDisarmSuccess()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                }
            })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MICALOCK AUTHORITY")
            .setSubtitle("Confirm Identity to Abort Siren")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
            
        // Initial Trigger
        biometricPrompt.authenticate(promptInfo)
    }

    private fun startCountdown() {
        val progressBar = findViewById<ProgressBar>(R.id.disarmProgress)
        val timerText = findViewById<TextView>(R.id.timerText)
        
        countDownTimer = object : CountDownTimer(TribeConstants.BIOMETRIC_GRACE_MS, 100) {
            override fun onTick(millisUntilFinished: Long) {
                progressBar.progress = millisUntilFinished.toInt()
                timerText.text = "${millisUntilFinished/1000}.${(millisUntilFinished%1000)/100}s"
            }

            override fun onFinish() {
                triggerHostile()
            }
        }.start()
    }

    private fun triggerHostile() {
        countDownTimer?.cancel()
        val intent = android.content.Intent(this, TribeService::class.java)
        intent.action = "ACTION_HOSTILE_ENGAGE" 
        startService(intent)
        finish()
    }

    private fun onDisarmSuccess() {
        countDownTimer?.cancel()
        
        // Persist "Off" state so it doesn't re-arm on boot
        SafeStorage.putMissionCriticalBoolean(this, "system_armed", false)

        val intent = android.content.Intent(this, TribeService::class.java)
        intent.action = "ACTION_SYSTEM_DISARM" 
        startService(intent)
        finish()
    }

    // Prevent Back Button Escape
    override fun onBackPressed() {
        // Do nothing. The only way out is Auth.
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }
}
