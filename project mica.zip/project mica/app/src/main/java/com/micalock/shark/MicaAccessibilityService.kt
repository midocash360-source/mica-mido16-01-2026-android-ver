package com.micalock.shark

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class MicaAccessibilityService : AccessibilityService() {

    private val chordBuffer = mutableListOf<Int>()
    private var lastTapTime = 0L
    private val CHORD_TIMEOUT_MS = 2000L
    // Target Sequence: Up, Up, Down
    private val TARGET_CHORD = listOf(
        KeyEvent.KEYCODE_VOLUME_UP,
        KeyEvent.KEYCODE_VOLUME_UP,
        KeyEvent.KEYCODE_VOLUME_DOWN
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for global key interception
    }

    override fun onInterrupt() {
        chordBuffer.clear()
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false

        val keyCode = event.keyCode
        val isVolumeKey = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN

        if (event.action == KeyEvent.ACTION_DOWN && isVolumeKey) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastTapTime > CHORD_TIMEOUT_MS) {
                chordBuffer.clear()
            }
            lastTapTime = currentTime
            
            chordBuffer.add(keyCode)
            if (chordBuffer.size > 3) chordBuffer.removeAt(0)
            
            if (isChordDetected()) {
                executeKillSwitch()
                chordBuffer.clear()
            }
        }
        
        // ACTIVE DEFENSE: Consume volume keys if in Hostile state
        if (isVolumeKey && HostileEnforcer.isHostile) {
            return true // Consume the event, preventing volume change
        }
        
        return super.onKeyEvent(event)
    }

    private fun isChordDetected(): Boolean {
        if (chordBuffer.size != 3) return false
        return chordBuffer == TARGET_CHORD
    }

    private fun executeKillSwitch() {
        // Send the "SAFE_MODE" command to the Shark Engine
        val intent = Intent(this, MicaForegroundService::class.java).apply {
            action = "SAFE_MODE"
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
