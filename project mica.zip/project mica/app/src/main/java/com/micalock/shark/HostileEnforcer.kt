package com.micalock.shark

import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.app.NotificationManager

object HostileEnforcer {
    
    @Volatile
    var isHostile = false
        private set
    private val mainHandler = Handler(Looper.getMainLooper())
    private var toneGenerator: ToneGenerator? = null
    
    // Background Thread for High-Frequency Ops (Volume Lock)
    private var enforcerThread: HandlerThread? = null
    private var enforcerHandler: Handler? = null
    
    private val volumeLockRunnable = object : Runnable {
        override fun run() {
            if (isHostile) {
                try {
                    audioManager?.setStreamVolume(
                        AudioManager.STREAM_ALARM,
                        audioManager?.getStreamMaxVolume(AudioManager.STREAM_ALARM) ?: 15,
                        0 
                    )
                } catch (e: Exception) {}
                enforcerHandler?.postDelayed(this, 50) // 50ms is sufficient and safer
            }
        }
    }

    // Strobe Runnable (Main Thread for UI/Camera logic safety)
    private var strobeState = false
    private val strobeRunnable = object : Runnable {
        override fun run() {
            if (isHostile) {
                try {
                    val cameraId = cameraManager?.cameraIdList?.get(0)
                    if (cameraId != null) {
                        strobeState = !strobeState
                        // cameraManager?.setTorchMode(cameraId, strobeState) 
                    }
                } catch (e: Exception) {}
                mainHandler.postDelayed(this, 100) 
            }
        }
    }

    private var audioManager: AudioManager? = null
    private var cameraManager: CameraManager? = null
    private var notificationManager: NotificationManager? = null

    @Synchronized
    fun initialize(context: Context) {
        val appCtx = context.applicationContext
        audioManager = appCtx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        cameraManager = appCtx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        notificationManager = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Start Background Thread
        if (enforcerThread == null) {
            enforcerThread = HandlerThread("SharkEnforcer").apply { start() }
            enforcerHandler = Handler(enforcerThread!!.looper)
        }
        
        ReconManager.initialize(appCtx)
    }

    @Synchronized
    fun engageHostileProtocol() {
        if (isHostile) return
        isHostile = true
        
        ReconManager.startRecon()

        try {
            if (notificationManager?.isNotificationPolicyAccessGranted == true) {
                notificationManager?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
        } catch (e: SecurityException) {}

        // Start Volume Lock on Background Thread
        enforcerHandler?.post(volumeLockRunnable)

        // Start Siren (Safe Re-init)
        try {
            if (toneGenerator == null) {
                toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            }
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK) 
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Start Strobe on Main Thread
        mainHandler.post(strobeRunnable)
    }

    @Synchronized
    fun fadeToSilent() {
        if (!isHostile) return
        mainHandler.removeCallbacks(strobeRunnable)
        try {
            toneGenerator?.stopTone()
        } catch (e: Exception) {}
    }

    @Synchronized
    fun wakeHell() {
        isHostile = false 
        engageHostileProtocol()
    }

    @Synchronized
    fun disarm() {
        isHostile = false
        enforcerHandler?.removeCallbacks(volumeLockRunnable)
        mainHandler.removeCallbacks(strobeRunnable)
        
        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {}
        
        ReconManager.stopRecon()
    }
}
