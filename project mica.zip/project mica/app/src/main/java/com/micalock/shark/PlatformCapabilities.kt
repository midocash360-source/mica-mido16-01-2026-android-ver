// PlatformCapabilities.kt – device capability detection and logging
package com.micalock.shark

import android.os.Build
import android.util.Log

/**
 * Central place to expose what the current device can do.
 * All flags are computed once at class load time and can be used throughout the app.
 */
object PlatformCapabilities {
    private const val TAG = "MICA_PLATFORM"

    val hasDirectBoot: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
    val hasVibrationEffect: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
    val hasNotificationChannels: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
    val hasSpecialUseForegroundType: Boolean = Build.VERSION.SDK_INT >= 34 // Android 14 (API 34)
    val hasModernKeyguard: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1

    /** Log all capabilities – useful for debugging on first launch */
    fun logCapabilities() {
        Log.i(TAG, "Device capabilities:")
        Log.i(TAG, "DirectBoot: $hasDirectBoot")
        Log.i(TAG, "VibrationEffect: $hasVibrationEffect")
        Log.i(TAG, "NotificationChannels: $hasNotificationChannels")
        Log.i(TAG, "SpecialUseForegroundType: $hasSpecialUseForegroundType")
        Log.i(TAG, "ModernKeyguard: $hasModernKeyguard")
    }

    /** Simple fingerprint for analytics / bug reports */
    fun getDeviceFingerprint(): String {
        return "${Build.MANUFACTURER}/${Build.MODEL}/API${Build.VERSION.SDK_INT}"
    }
}
