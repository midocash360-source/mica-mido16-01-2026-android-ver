package com.micalock.shark

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class MicaForegroundService : Service() {

    private var vibrator: Vibrator? = null
    private val CHANNEL_ID = "MicaLock_Core"
    private val NOTIFICATION_ID = 999

    override fun onCreate() {
        super.onCreate()
        
        // Initialize Vibrator based on Android Version
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        // Initialize Notification Channel for Foreground Persistence
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // [CRITICAL] Must promote to Foreground IMMEDIATELY, even if intent is null (Sticky Restart)
        createNotificationChannel()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // API 34+
                startForeground(NOTIFICATION_ID, createNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(NOTIFICATION_ID, createNotification())
            }
        } catch (e: Exception) {
             android.util.Log.e("MicaFGS", "Foreground Start Failed: ${e.message}")
             stopSelf() // CRITICAL: Stop service to prevent ForegroundServiceDidNotStartInTimeException
        }

        if (intent == null) {
            android.util.Log.w("MicaForegroundService", "Service restarted with null intent")
            return START_STICKY
        }

        val action = intent.action
        if (action != null) {
            when (action) {
                "ACTION_ARM" -> armSystem()
                "ACTION_TRIGGER_HOSTILE" -> engageKineticEngine()
                "ACTION_TRIGGER_BLUFF" -> engageBluff()
                "STOP", "SAFE_MODE", "ACTION_SYSTEM_DISARM" -> disengage()
            }
        }

        // Stickiness ensures the service restarts if the system kills it for memory
        return START_STICKY
    }

    private fun engageKineticEngine() {
        if (vibrator?.hasVibrator() == true) {
            // 8.2Hz Frequency Implementation
            // Period = ~122ms. 61ms ON / 61ms OFF.
            // 0 index indicates repeat from the beginning (Infinite Loop)
            val timings = longArrayOf(0, 61, 61)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createWaveform(timings, 0)
                vibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, 0)
            }
        }
    }
    
    private fun engageBluff() {
         if (vibrator?.hasVibrator() == true) {
             // Single heavy mechanical 'clunk' to simulate power relay cut
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)
                vibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(60)
            }
         }
    }

    private fun armSystem() {
        val intent = Intent(this, TribeService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun disengage() {
        vibrator?.cancel()
        val intent = Intent(this, TribeService::class.java)
        intent.action = "ACTION_SYSTEM_DISARM"
        try {
            startService(intent)
        } catch (e: Exception) {
            // Service already dead or background start restricted.
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null // We do not allow binding, only StartCommand interactions
    }
    
    override fun onDestroy() {
        disengage()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Shark Engine Active",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Monitoring sensors and hardware interrupts."
                lightColor = Color.CYAN
                enableLights(true)
                setSound(null, null) // Silent notification to maintain stealth
                enableVibration(false) // Notification itself should not vibrate, only the engine logic
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("MicaLock Shark Active")
            .setContentText("Kinetic Deterrent System Online")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build()
    }
}
