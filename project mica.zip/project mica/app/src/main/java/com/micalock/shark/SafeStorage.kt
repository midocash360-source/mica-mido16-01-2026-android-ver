// SafeStorage.kt – unified storage tier handling
package com.micalock.shark

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log

/**
 * Helper that abstracts away the three main storage tiers used in this app.
 *   - MISSION_CRITICAL: data that must survive Direct Boot (device‑protected)
 *   - USER_DATA: normal app data (credential‑encrypted, available after unlock)
 *   - CACHE: temporary data that can be cleared at any time
 */
object SafeStorage {
    private const val TAG = "SafeStorage"

    enum class StorageTier {
        MISSION_CRITICAL,
        USER_DATA,
        CACHE
    }

    /** Return the appropriate SharedPreferences instance for the given tier. */
    fun getPreferences(context: Context, tier: StorageTier): SharedPreferences {
        return when (tier) {
            StorageTier.MISSION_CRITICAL -> {
                // Device‑protected storage is only available on API 24+ (Direct Boot)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val deviceContext = context.createDeviceProtectedStorageContext()
                    deviceContext.getSharedPreferences("mica_mission_critical", Context.MODE_PRIVATE)
                } else {
                    // Fallback to normal prefs – not ideal but prevents crashes on very old devices
                    Log.w(TAG, "Device‑protected storage not available, falling back to default prefs")
                    context.getSharedPreferences("mica_mission_critical", Context.MODE_PRIVATE)
                }
            }
            StorageTier.USER_DATA -> {
                context.getSharedPreferences("mica_user_data", Context.MODE_PRIVATE)
            }
            StorageTier.CACHE -> {
                // Simple in‑memory cache using a private prefs file marked MODE_PRIVATE
                context.getSharedPreferences("mica_cache", Context.MODE_PRIVATE)
            }
        }
    }

    // Convenience wrappers for the most common mission‑critical values
    fun putMissionCriticalBoolean(context: Context, key: String, value: Boolean) {
        val prefs = getPreferences(context, StorageTier.MISSION_CRITICAL)
        prefs.edit().putBoolean(key, value).commit() // commit to guarantee persistence before reboot
    }

    fun getMissionCriticalBoolean(context: Context, key: String, default: Boolean = false): Boolean {
        val prefs = getPreferences(context, StorageTier.MISSION_CRITICAL)
        return prefs.getBoolean(key, default)
    }

    // Add similar helpers for String, Int, Long as needed
}
