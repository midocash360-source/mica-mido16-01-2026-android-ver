// CompatUtils.kt – central version‑guarded helpers
package com.micalock.shark

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.app.KeyguardManager
import androidx.core.content.ContextCompat
import android.util.Log

/**
 * Collection of small helper functions that hide API‑level differences.
 * All methods are safe to call on any Android version supported by the app (API 26+).
 */
object CompatUtils {
    private const val TAG = "CompatUtils"

    /** Vibrate the device for the given duration (ms). */
    fun vibrate(context: Context, durationMs: Long) {
        val vibrator = ContextCompat.getSystemService(context, Vibrator::class.java)
        if (vibrator == null) {
            Log.w(TAG, "Vibrator service not available")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }

    /** Dismiss the keyguard (lock screen) if the app is allowed to do so. */
    fun dismissKeyguard(activity: androidx.appcompat.app.AppCompatActivity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            val km = ContextCompat.getSystemService(activity, KeyguardManager::class.java)
            km?.requestDismissKeyguard(activity, null)
        } else {
            // Legacy approach – set window flags (deprecated but still works on old devices)
            @Suppress("DEPRECATION")
            activity.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        }
    }

    /** Create a notification channel if needed (API 26+). */
    fun createNotificationChannel(context: Context, channelId: String, name: String, description: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, name, importance).apply {
                this.description = description
            }
            val manager = ContextCompat.getSystemService(context, NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
