package com.micalock.shark

import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue

object WifiDirectHighway {

    private val payloadQueue = ConcurrentLinkedQueue<File>()
    private var isConnected = false

    private val MAX_QUEUE_SIZE = 50

    fun queuePayload(file: File) {
        if (payloadQueue.size >= MAX_QUEUE_SIZE) {
            payloadQueue.poll() // Drop oldest to make room for newest intel
        }
        payloadQueue.add(file)
        if (isConnected) {
            transmitNext()
        }
    }

    private fun transmitNext() {
        val file = payloadQueue.poll() ?: return
        
        // REAL SOCKET LOGIC WOULD GO HERE
        // 1. Open Socket to Group Owner IP
        // 2. Stream File Bytes
        // 3. Confirm Receipt
        
        // Mocking Transmission
        println("ReconHighway: Transmitting ${file.name} (${file.length()} bytes)")
    }
    
    fun setConnectionState(connected: Boolean) {
        isConnected = connected
        if (connected) {
            // Flush Cache
            while (payloadQueue.isNotEmpty()) {
                transmitNext()
            }
        }
    }
}
