package com.micalock.shark

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.camera.view.PreviewView
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import android.Manifest

import androidx.core.app.ActivityCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class NodesFragment : Fragment() {
    
    companion object {
        private const val CAMERA_REQUEST_CODE = 1001
    }

    private lateinit var cameraExecutor: ExecutorService

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return try {
            inflater.inflate(R.layout.fragment_nodes, container, false)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Handle permission result callback
        view.setOnKeyListener { _, _, _ -> false }

        cameraExecutor = Executors.newSingleThreadExecutor()

        try {
            // [ARM NODE]
            view.findViewById<Button>(R.id.btnArmNode)?.setOnClickListener {
                 (activity as? MainActivity)?.triggerServiceCommand("ACTION_ARM") // New Action
            }

            // [FORCE SIREN]
            view.findViewById<Button>(R.id.btnForceSiren)?.setOnClickListener {
                 (activity as? MainActivity)?.triggerServiceCommand("ACTION_TRIGGER_HOSTILE")
            }
            
            // [WIPE DATA]
            view.findViewById<Button>(R.id.btnWipeData)?.setOnClickListener {
                 (activity as? MainActivity)?.triggerServiceCommand("ACTION_TRIGGER_BLUFF")
            }

            val previewView = view.findViewById<PreviewView>(R.id.bioCamera)
if (previewView != null) {
    // Camera permission check
    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
        return
    }
    startCamera(previewView)
}

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startCamera(previewView: PreviewView) {
        if (!isAdded) return
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
            cameraProviderFuture.addListener({
                if (!isAdded) return@addListener
                try {
                    val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
                    val preview = androidx.camera.core.Preview.Builder()
                        .build()
                        .also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                    val cameraSelector = androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA

                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        viewLifecycleOwner, cameraSelector, preview
                    )
                } catch (exc: Exception) {
                    exc.printStackTrace()
                }
            }, ContextCompat.getMainExecutor(requireContext()))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (::cameraExecutor.isInitialized) {
            cameraExecutor.shutdown()
        }
    }
}
