package com.micalock.shark

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2

class MainActivity : AppCompatActivity() {

    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            // Initialize Vibrator for Haptic Tests
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setupTabs()
        setupScanningPulse()
    }

    private fun setupTabs() {
        val pager = findViewById<ViewPager2>(R.id.mainPager) ?: return
        pager.adapter = MainPagerAdapter(this)
        pager.isUserInputEnabled = true

        val tabs = listOf(
            findViewById<TextView>(R.id.tabNodes),
            findViewById<TextView>(R.id.tabTactical),
            findViewById<TextView>(R.id.tabTribe),
            findViewById<TextView>(R.id.tabStrike)
        )

        // Tab Click Listeners
        tabs.forEachIndexed { index, view ->
            view?.setOnClickListener {
                pager.currentItem = index
                updateTabVisuals(index, tabs)
            }
        }

        // Sync visual state on swipe
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateTabVisuals(position, tabs)
            }
        })
        
        updateTabVisuals(0, tabs) // Initial state
    }

    private fun updateTabVisuals(selected: Int, tabs: List<TextView?>) {
        tabs.forEachIndexed { index, view ->
            if (view == null) return@forEachIndexed
            if (index == selected) {
                view.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.tactical_cyan))
                view.typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
                view.alpha = 1.0f
                view.textSize = 14f
            } else {
                view.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.tactical_gray))
                view.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                view.alpha = 0.6f
                view.textSize = 12f
            }
        }
    }

    private fun getTabName(index: Int): String {
         return when (index) {
             0 -> "NODES"
             1 -> "TACTICAL"
             2 -> "TRIBE"
             3 -> "STRIKE"
             else -> "?"
         }
    }

    override fun onResume() {
        super.onResume()
        setupScanningPulse()
    }

    override fun onPause() {
        super.onPause()
        findViewById<View>(R.id.scannerLine)?.clearAnimation()
    }

    private fun setupScanningPulse() {
        val scanner = findViewById<View>(R.id.scannerLine) ?: return
        try {
            val animation = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.radar_sweep)
            scanner.startAnimation(animation)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun triggerServiceCommand(cmd: String) {
        try {
            // Persist State for Boot Survival
            when (cmd) {
                "ACTION_ARM" -> SafeStorage.putMissionCriticalBoolean(this, "system_armed", true)
                "STOP", "SAFE_MODE" -> SafeStorage.putMissionCriticalBoolean(this, "system_armed", false)
            }

            val intent = Intent(this, MicaForegroundService::class.java)
            intent.action = cmd
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    inner class MainPagerAdapter(activity: AppCompatActivity) : androidx.viewpager2.adapter.FragmentStateAdapter(activity) {
        override fun getItemCount(): Int = 4
        override fun createFragment(position: Int): androidx.fragment.app.Fragment {
            return when (position) {
                0 -> NodesFragment()
                2 -> TribeFragment()
                else -> PlaceholderFragment.newInstance(getTabName(position))
            }
        }
    }
}
