package com.micalock.shark

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import java.util.ArrayDeque
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import com.micalock.shark.RssiUkfHelper

    private val rssiUkf = RssiUkfHelper()

class TribeService : Service(), SensorEventListener {

    private val binder = LocalBinder()
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var vibrator: Vibrator? = null

    // BLE Components
    private var bluetoothGatt: BluetoothGatt? = null
    private var peerMacAddress: String? = null
    private var rssiHandler = Handler(Looper.getMainLooper())
    private var isConnected = false
    private lateinit var safeContext: Context
    private val activeGattConnections = mutableListOf<BluetoothGatt>()

    // Heuristic State
    private var lastMovementTime = 0L
    private var isStationary = false
    
    // RSSI Median Filter
    private val rssiWindow = ArrayDeque<Int>()
    private val RSSI_WINDOW_SIZE = 10
    private var smoothedRssi = -100 // Default to "Far/Unknown" for safety

    // Tactical State
    private var inPreHostileState = false
    private val hostileHandler = Handler(Looper.getMainLooper())

    companion object {
        const val ACTION_PEER_CONNECTED = "com.micalock.shark.PEER_CONNECTED"
        const val ACTION_PEER_DISCONNECTED = "com.micalock.shark.PEER_DISCONNECTED"
        const val ACTION_RSSI_UPDATE = "com.micalock.shark.RSSI_UPDATE"
    }

    inner class LocalBinder : Binder() {
        fun getService(): TribeService = this@TribeService
    }

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        
        // Initialize Safe Context for Direct Boot Persistence
        safeContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            applicationContext.createDeviceProtectedStorageContext()
        } else {
            applicationContext
        }
        
        HostileEnforcer.initialize(this) 

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // API 34+
                startForeground(777, createNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(777, createNotification())
            }
        } catch (e: Exception) { // SecurityException or FgsIllegalState
             android.util.Log.e("TribeService", "Failed to start foreground: ${e.message}")
             stopSelf() // CRITICAL: Prevent OS crash
        }
        
        startRssiMonitoring()
        
        // AUTO-HEAL: Restore last peer connection on start (even after reboot)
        val prefs = safeContext.getSharedPreferences("SharkPrefs", Context.MODE_PRIVATE)
        val lastPeer = prefs.getString("last_peer_mac", null)
        if (lastPeer != null) {
            connectToPeer(lastPeer)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "Tribe_Mesh_Link"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Tribe Mesh", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Tribe Mesh Active")
            .setContentText("Monitoring Link & Sensors")
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .build()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                val x = it.values[0]
                val y = it.values[1]
                val z = it.values[2]
                
                // Sensor Guard
                if (it.values.any { v -> v.isNaN() || v.isInfinite() }) return

                val magnitude = sqrt((x*x + y*y + z*z).toDouble()).toFloat()
                val currentTime = System.currentTimeMillis()

                // Check Movement (Stationary Logic)
                if (Math.abs(magnitude - 9.8) > 0.5) {
                     lastMovementTime = currentTime
                     isStationary = false
                }
                
                if (currentTime - lastMovementTime > 60000) {
                    isStationary = true
                }

                // DUAL-CHECK: SNATCH TRIGGER (Requires Link)
                if (isConnected && smoothedRssi < TribeConstants.RSSI_HOSTILE_ZONE) {
                    if (magnitude > TribeConstants.SNATCH_VELOCITY_THRESHOLD) {
                        triggerPreHostileSequence("SNATCH DETECTED")
                    }
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private val rssiRunnable = object : Runnable {
        override fun run() {
            if (isConnected && bluetoothGatt != null) {
                try {
                    bluetoothGatt?.readRemoteRssi()
                } catch (e: SecurityException) {}
            }
            val delay = if (isStationary) 5000L else 2000L
            rssiHandler.postDelayed(this, delay)
        }
    }

    private fun startRssiMonitoring() {
        rssiHandler.post(rssiRunnable)
    }
    
    fun connectToPeer(address: String) {
        peerMacAddress = address
        
        // Persist peer for reboot survival
        safeContext.getSharedPreferences("SharkPrefs", Context.MODE_PRIVATE)
            .edit().putString("last_peer_mac", address).apply()

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bluetoothManager?.adapter
        val localMac = try { adapter?.address } catch (e: SecurityException) { null } // Legacy/System apps only
        
        // Arbitration: If we can't determine local MAC (Android 6+), we assume we are client to force connection.
        // If we CAN determine it (System app / Root), we arbitrate.
        var shouldConnect = true
        if (localMac != null && localMac != "02:00:00:00:00:00") {
             if (localMac >= address) {
                 shouldConnect = false
                 android.util.Log.i("TribeService", "Arbitration: Waiting for remote peer to connect.")
             }
        }

        if (shouldConnect && adapter != null) {
            val device = adapter.getRemoteDevice(address)
            try {
                bluetoothGatt = device.connectGatt(this, false, gattCallback)
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }
    }
    
    private val reconnectionHandler = Handler(Looper.getMainLooper())
    private val reconnectionRunnable = Runnable {
        peerMacAddress?.let { connectToPeer(it) }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                isConnected = true
                reconnectionHandler.removeCallbacks(reconnectionRunnable) // Clear any pending retries
                sendBroadcast(Intent(ACTION_PEER_CONNECTED))
                try {
                    gatt?.discoverServices()
                } catch (e: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isConnected = false
                try {
                    bluetoothGatt?.close()
                    bluetoothGatt = null
                } catch (e: SecurityException) {}
                
                sendBroadcast(Intent(ACTION_PEER_CONNECTED).apply { action = ACTION_PEER_DISCONNECTED }) 
                
                // RESILIENCE: Attempt auto-reconnect after 5 seconds
                if (peerMacAddress != null) {
                    reconnectionHandler.postDelayed(reconnectionRunnable, 5000)
                }
            }
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt?, rssi: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                processRssi(rssi)
            }
        }
    }
    
    private fun processRssi(rssi: Int) {
        if (rssiWindow.size >= RSSI_WINDOW_SIZE) {
            rssiWindow.removeFirst()
        }
        rssiWindow.addLast(rssi)
        
        val sorted = rssiWindow.sorted()
        smoothedRssi = if (sorted.isNotEmpty()) sorted[sorted.size / 2] else rssi

        val intent = Intent(ACTION_RSSI_UPDATE)
        intent.putExtra("RSSI", smoothedRssi)
        sendBroadcast(intent)

        if (smoothedRssi < TribeConstants.RSSI_DRIFT_START) {
            if (smoothedRssi < TribeConstants.RSSI_HOSTILE_ZONE) {
                 if (isStationary) {
                     triggerPulse("FAR BUT STATIONARY")
                 } 
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            android.util.Log.w("TribeService", "Service restarted with null intent")
            return START_STICKY
        }
        val action = intent.action
        if (action != null) {
            when (action) {
                "ACTION_SYSTEM_DISARM" -> {
                    disarmSystem()
                }
                "ACTION_HOSTILE_ENGAGE" -> {
                    HostileEnforcer.engageHostileProtocol()
                }
            }
        }
        return START_STICKY
    }

    private fun triggerPreHostileSequence(reason: String) {
        android.util.Log.d("TribeService", "Pre-Hostile Triggered: $reason")
        if (inPreHostileState) return
        inPreHostileState = true
        
        if (vibrator?.hasVibrator() == true) {
            val gracePattern = longArrayOf(0, 200, 100, 200) 
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(gracePattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(gracePattern, -1)
            }
        }
        
        hostileHandler.postDelayed({
            if (inPreHostileState) {
                HostileEnforcer.engageHostileProtocol()
            }
        }, TribeConstants.BIOMETRIC_GRACE_MS + 2000)

        val launchIntent = Intent(this, DisarmActivity::class.java)
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
    }

    fun disarmSystem() {
        inPreHostileState = false
        hostileHandler.removeCallbacksAndMessages(null)
        HostileEnforcer.disarm()
        vibrator?.cancel()
    }

    private fun triggerPulse(reason: String) {
        android.util.Log.v("TribeService", "Pulse Triggered: $reason")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(300)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
        rssiHandler.removeCallbacks(rssiRunnable)
        HostileEnforcer.disarm()
        try {
            bluetoothGatt?.close()
        } catch (e: SecurityException) {}
    }
}
