package com.micalock.shark

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment

import android.Manifest
import android.content.Context
import android.content.Intent
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class TribeFragment : Fragment() {

    private var tribeService: TribeService? = null
    
    // Service Binding
    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: android.content.ComponentName?, service: android.os.IBinder?) {
            val binder = service as TribeService.LocalBinder
            tribeService = binder.getService()
            view?.findViewById<TextView>(R.id.connectionStatus)?.text = "STATUS: SERVICE LINKED"
        }
        override fun onServiceDisconnected(name: android.content.ComponentName?) {
            tribeService = null
        }
    }

    // QR SCAN LAUNCHER
    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            val scannedData = result.contents // Should be "MICALOCK:MAC_ADDRESS:UUID"
            if (scannedData.startsWith("MICALOCK:")) {
                val parts = scannedData.split(":")
                if (parts.size >= 2) {
                    val peerMac = parts[1]
                    view?.findViewById<TextView>(R.id.connectionStatus)?.text = "PEER FOUND: $peerMac"
                    // Prompt Manual Accept here (future), for now auto-connect
                    tribeService?.connectToPeer(peerMac)
                }
            }
        }
    }

    // UI Updates
    private val rssiReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (TribeService.ACTION_RSSI_UPDATE == intent?.action) {
                val rssi = intent.getIntExtra("RSSI", 0)
                updateSignalMeter(rssi)
            }
        }
    }
    
    private fun updateSignalMeter(rssi: Int) {
        val statusView = view?.findViewById<TextView>(R.id.connectionStatus)
        val statusText = "SIGNAL: $rssi dBm"
        statusView?.text = statusText
        
        when {
            rssi > TribeConstants.RSSI_SAFE_ZONE -> {
                statusView?.setTextColor(android.graphics.Color.GREEN) // SAFE
            }
            rssi < TribeConstants.RSSI_HOSTILE_ZONE -> {
                statusView?.setTextColor(android.graphics.Color.RED) // HOSTILE
            }
            else -> {
                statusView?.setTextColor(android.graphics.Color.YELLOW) // DRIFT
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_tribe, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Register RSSI Receiver
        val filter = android.content.IntentFilter(TribeService.ACTION_RSSI_UPDATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requireContext().registerReceiver(rssiReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            requireContext().registerReceiver(rssiReceiver, filter)
        }
        
        // Start Service
        val intent = Intent(requireContext(), TribeService::class.java)
        requireContext().startService(intent) // Ensure it's running
        requireContext().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        val qrScannerLine = view.findViewById<View>(R.id.qrScannerLine)
        // Animate Scanner
        qrScannerLine.post {
            val h = view.findViewById<View>(R.id.qrCodeImage).height.toFloat()
            android.animation.ObjectAnimator.ofFloat(qrScannerLine, "translationY", 0f, h).apply {
                 duration = 1500
                 repeatCount = android.animation.ObjectAnimator.INFINITE
                 repeatMode = android.animation.ObjectAnimator.REVERSE
                 start()
            }
        }
        
        // Deploy Invite
        view.findViewById<Button>(R.id.btnDeployInvite).setOnClickListener {
             val safeContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                 requireContext().createDeviceProtectedStorageContext()
             } else {
                 requireContext()
             }
             val prefs = safeContext.getSharedPreferences("SharkPrefs", Context.MODE_PRIVATE)
             var identity = prefs.getString("tribe_id", null)
             if (identity == null) {
                 identity = java.util.UUID.randomUUID().toString().take(8).uppercase()
                 prefs.edit().putString("tribe_id", identity).apply()
             }
             
             val handshakeId = "MICALOCK:$identity"
             try {
                 val bitMatrix = MultiFormatWriter().encode(handshakeId, BarcodeFormat.QR_CODE, 400, 400)
                 val bitmap = BarcodeEncoder().createBitmap(bitMatrix)
                 view.findViewById<ImageView>(R.id.qrCodeImage).setImageBitmap(bitmap)
                 view.findViewById<TextView>(R.id.connectionStatus).text = "INVITE: $identity"
             } catch (e: Exception) {}
        }
        
        // Join Tribe -> SIMULATE HOSTILE / DISARM for now since we don't have 2 physical phones to test BLE
        // I will repurpose the JOIN button for testing ENFORCER if that's okay, or add a hidden trigger.
        // Actually, let's keep Join Tribe as Scan, and add a LongClick to Deploy Invite as Panic?
        
        // LONG CLICK "DEPLOY INVITE" -> PANIC TEST
        view.findViewById<Button>(R.id.btnDeployInvite).setOnLongClickListener {
            HostileEnforcer.engageHostileProtocol()
            true
        }
        
        // LONG CLICK "JOIN TRIBE" -> DISARM
        view.findViewById<Button>(R.id.btnJoinTribe).setOnLongClickListener {
            try {
               tribeService?.disarmSystem() 
               HostileEnforcer.disarm()
            } catch (e: Exception) {}
            true
        }

        view.findViewById<Button>(R.id.btnJoinTribe).setOnClickListener {
             // SCAN QR
             val options = ScanOptions()
             options.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
             options.setPrompt("SCAN GUARDIAN INVITE")
             options.setBeepEnabled(true)
             options.setBarcodeImageEnabled(false)
             scanLauncher.launch(options)
        }
    }
    
    
    override fun onDestroyView() {
        super.onDestroyView()
        try {
            context?.unregisterReceiver(rssiReceiver)
        } catch (e: IllegalArgumentException) {
            // Receiver not registered, ignore
        }
        context?.unbindService(serviceConnection)
    }
}
